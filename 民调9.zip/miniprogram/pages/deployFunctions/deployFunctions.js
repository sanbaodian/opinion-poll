// pages/deployFunctions/deployFunctions.js
const app = getApp()
const db = wx.cloud.database()
import Dialog from '../../vant/dialog/dialog';
import Toast from '../../vant/toast/toast';
wx.cloud.init({
  env: 'mindia-d6ac8a'
})
Page({

  /**
   * 页面的初始数据
   */
  data: {
    openid: '',
    avatarUrl: '../index/user-unlogin.png',
    counterId: '',
    guanli_openid:'',
    laizi_openGId:'',
    zhuti: [],
    timu: '',
    gangmu:[],
    temp_gangmu:[],
    tmp_openId:'',
    tmp_openGId:'',
    tmp_up: '',
    tmp_down: '',
    tmp_id:'',
    duotou:true,
    index:'',
    shuru:false,
    shuruzhi0:"点此输入，完成后再次点击加项即可！",
    shuruzhi:'',
    jici:0,
    input2:false,
    iconType: [
       'info', 'clear'
    ],
    show:false,
    jian:false,
    username:'',
    tmp_ids:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log("接收到counterId=" + options.counterId);
    if (options.counterId){
      this.setData({
        counterId: options.counterId
      });
      wx.setStorageSync('counterId', options.counterId);
    }else{
      this.setData({
        counterId: wx.getStorageInfoSync('counterId')
      });

    }

    this.onGetOpenid();
    this.gm_onQuery();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {


  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },
  onGetOpenid: function() {
    // 调用云函数
    wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        console.log('主题内容页面 openid: ', res.result.openid)
        app.globalData.openid = res.result.openid;
        this.setData({
          openid: res.result.openid
        })
        fail: err => {
          console.error('登陆信息获取失败', err)
          wx.navigateTo({
            url: '../deployFunctions/deployFunctions',
          })
        }
      }
    })
    this.onQuery();
  },

  onQuery: function() {
    var that = this;
    const db = wx.cloud.database()
    if (!that.data.counterId){
      wx.showToast({
        title: '没有记录',
      })
    }
    db.collection('mindiao').where({
      _id: that.data.counterId
    }).get({
      success: res => {
        console.log("主题管理者：" + res.data[0]._openid)
        console.log(res.data[0].duotou)
        that.setData({
          zhuti: JSON.stringify(res.data, null, 2),
          timu: res.data[0].name,
          guanli_openId: res.data[0]._openid,
          laizi_openGId: res.data[0].gID,
          duotou:res.data[0].duotou
        })
        console.log('0:', that.data.jian);
        console.log('1:',that.data.guanli_openId);
        console.log('2:', app.globalData.openid);
        if (that.data.guanli_openId === app.globalData.openid){
          that.setData({
            jian:true
          })
          console.log('3:', that.data.jian);
        }  
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询失败'
        })
        console.error('查询失败：', err)
      }
    })
  },

  gm_onQuery: function () {
    const db = wx.cloud.database()
    var that = this;
    db.collection('yiji').where({
      counterId: that.data.counterId
    }).get({
      success: res => {
        that.setData({
          gangmu: res.data
        })
        console.log('纲目数据获取成功: ', res.data);

      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('纲目数据获取失败：', err)
      }
    })
  },
 

  listenerInput: function (e) {
    console.log(e.detail.value);
    this.data.shuruzhi = e.detail.value;
    this.setData({
      shuruzhi: e.detail.value
    })
  },
  input2: function () {

      this.setData({
        input2: true,
        shuruzhi: '',
        shuruzhi0: "点此输入，完成输入后再次点击加项即可！",
        shuru:false

      })
    
  },
  add: function () {
    this.setData({
      shuru: true,
      jici:this.data.jici*1 + 1
    })
    if (this.data.jici % 2 == 0 && this.data.shuruzhi!=''){
      const db = wx.cloud.database()
      db.collection('yiji').add({
        data: {
          name: this.data.timu,
          gID: wx.getStorageSync('gID'),
          counterId:this.data.counterId,
          input3: false,
          gangmu: this.data.shuruzhi,
          up: 1,
          down: 0,
          del: false
        },
        success: res => {
          wx.showToast({
            title: '加项成功',
          })
          this.setData({
            tmp_id: '',
            count: null,
            shuru: false
          })
          this.input2();
          this.gm_onQuery();
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '加项失败',
          })
          console.error('加项失败：', err)
        }
      })
    }
    },

  del: function () {
    var that = this;
    if (that.data.tmp_id){
      const db = wx.cloud.database()
      db.collection('mindiao').doc(that.data.counterId).get({
        success: function (res) {
          console.log(res.data._openid)
       
            wx.cloud.callFunction({
              // 要调用的云函数名称
              name: 'del',
              // 传递给云函数的参数
              data: {
                id: that.data.tmp_id
              },
              success: res => {
                wx.showToast({
                  title: '删除成功',
                })
                that.gm_onQuery();
              },
              fail: err => {
                wx.showToast({
                  icon: 'none',
                  title: '删除失败',
                })
              },
              complete: () => {
                // ...
              }
            })

       

        }
      })     

    }
    


  },
  goHome: function() {
    const pages = getCurrentPages()
    if (pages.length === 2) {
      this.setData({
        jian:false
      })
      wx.navigateBack()
    } else if (pages.length === 1) {
      this.setData({
        jian: false
      })
      wx.redirectTo({
        url: '../index/index',
      })
    } else {
      this.setData({
        jian: false
      })
      wx.reLaunch({
        url: '../index/index',
      })
    }
  },

 
  dianji: function (e) {
    var that = this;
    var index = e.currentTarget.dataset.id; 
    console.log(index);
    that.setData({
      tmp_id: index,
      jici: that.data.jici * 1 + 1
    })


    if (that.data.duotou ==false) {
      if (that.data.tmp_ids.indexOf(index) !== -1) {

        Toast('主题限定：每次只能投一票！');
        return;
      }
      console.log(wx.getStorageSync('duotou'))
      console.log(that.data.jici)
      console.log("yunxu")
      that.data.tmp_ids.push(e.currentTarget.dataset.id);
      that.removeRepeat(that.data.tmp_ids);
      console.log(index);
      db.collection('yiji').doc(index).get().then(res => {
        console.log("选项管理者：" + res.data._openid);
        that.setData({
          tmp_openid: res.data._openid
        })
        if (that.data.guanli_openId != app.globalData.openid) {
          that.setData({
            jian: false
          })
        }
        if (that.data.tmp_openid === app.globalData.openid) {
          that.setData({
            jian: true
          })
        }

        wx.cloud.callFunction({
          // 要调用的云函数名称
          name: 'post',
          // 传递给云函数的参数
          data: {
            id: index
          },
          success: res => {
            wx.showToast({
              icon: 'none',
              title: '支持成功',
            })
          },
          fail: err => {
            wx.showToast({
              icon: 'none',
              title: '支持失败',
            })
          },
          complete: () => {
            // ...
          }
        })
      });
      this.gm_onQuery();
    }
    else{
      db.collection('yiji').doc(index).get().then(res => {
        console.log("选项管理者：" + res.data._openid);
        that.setData({
          tmp_openid: res.data._openid
        })
        if (that.data.guanli_openId != app.globalData.openid) {
          that.setData({
            jian: false
          })
        }
        if (that.data.tmp_openid === app.globalData.openid) {
          that.setData({
            jian: true
          })
        }

        wx.cloud.callFunction({
          // 要调用的云函数名称
          name: 'post',
          // 传递给云函数的参数
          data: {
            id: index
          },
          success: res => {
            wx.showToast({
              icon: 'none',
              title: '支持成功',
            })
          },
          fail: err => {
            wx.showToast({
              icon: 'none',
              title: '支持失败',
            })
          },
          complete: () => {
            // ...
          }
        })
      });
      this.gm_onQuery();
      

      
    }




   

},
onChange(event) {
    var that = this;
    console.log(event);
    that.setData({
      shuruzhi: event.detail.value
    })
  },
  new: function () {
    // wx.navigateTo({
    //  url: '../databaseGuide/databaseGuide',
    // })
    this.setData({
      show: true
    })
  },
  onChange(event) {
    // event.detail 为当前输入的值
    console.log(event.detail);
    this.setData({
      shuruzhi: event.detail
    })
  },
  onClose(event) {
    if (event.detail === 'confirm') {
      // 异步关闭弹窗
      setTimeout(() => {

        const db = wx.cloud.database()
        if (this.data.shuruzhi) {
          db.collection('yiji').add({
            data: {
              gangmu: this.data.shuruzhi,
              counterId: wx.getStorageSync('counterId'),
              up:1,
              del:false,
              name:this.data.timu,
              down:0,
              gID: wx.getStorageSync('counterId'),
              input3:false
            },
            success: res => {
              //在返回结果中会包含新创建的主题的 _id
              console.log('增项成功，选项 _id: ', res._id);
              this.input2();
              this.gm_onQuery();
            },
            fail: err => {
              wx.showToast({
                icon: 'none',
                title: '增项失败'
              })
              console.error('增项失败：', err)
            }
          })
        };

        this.setData({
          show: false
        });
      }, 1000);
    } else {
      this.setData({
        show: false
      });
    }
  },
onShareAppMessage: function () {
    return {
      title: '主题民调：' + this.data.timu,
      desc: '',
      path: 'pages/deployFunctions/deployFunctions?counterId=' + this.data.counterId
    }
  },
  removeRepeat:function (nodes) {
    var arr = [], obj = {};
    for(var i = 0, l = nodes.length; i<l;i++ ){
  var item = nodes[i];
  console.log(item);
  if (obj[item]) {
    obj[item] += 1;
  } else {
    obj[item] = 1;
    arr.push(nodes[i])
  }
}
console.log(obj)
return arr;

}
})