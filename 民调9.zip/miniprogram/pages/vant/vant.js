import Dialog from '../../vant/dialog/dialog';
const app = getApp()
Page({
  data: {
    show: true,
    checked:false,
    username: '',
    password: '',
    counterId:'',
    guanli_openId:'',
    fileID: '',
    cloudPath: '',
    imagePath: ''
  },

  onClose(event) {
    if (event.detail === 'confirm') {
      // 异步关闭弹窗
      setTimeout(() => {
        this.setData({
          show: false
        });
      }, 1000);
    } else {
      this.setData({
        show: false
      });
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const {
      fileID,
      cloudPath,
      imagePath,
    } = app.globalData

    this.setData({
      fileID,
      cloudPath,
      imagePath,
    })
    console.log("接收到counterId=" + options.counterId);
    if (options.counterId) {
      this.setData({
        counterId: options.counterId
      });
      wx.setStorageSync('counterId', options.counterId);
      this.onQuery();
    }


  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  onChange:function(){
   this.setData({
     checked:!this.data.checked
   })
   wx.setStorage({
     key:'duotou',
     data:this.data.checked
     })
    console.log(wx.getStorageSync('duotou'))
    var db = wx.cloud.database()
    db.collection('mindiao').doc(this.data.counterId).update({
      // data 传入需要局部更新的数据
      data: {
        // 表示将 done 字段置为 true
        duotou: wx.getStorageSync('duotou')
      }
    })
      .then(console.log)
      .catch(console.error)

  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
   onQuery: function () {
    var that = this;
    const db = wx.cloud.database()
    if (!that.data.counterId) {
      wx.showToast({
        title: '没有记录',
      })
    }
    db.collection('mindiao').where({
      _id: that.data.counterId
    }).get({
      success: res => {
        console.log("主题管理者：" + res.data[0]._openid)
        console.log(res.data[0].duotou)
        that.setData({
          zhuti: JSON.stringify(res.data, null, 2),
          timu: res.data[0].name,
          guanli_openId: res.data[0]._openid,
          laizi_openGId: res.data[0].gID,
          duotou: res.data[0].duotou
        })
        console.log('1:', that.data.guanli_openId);
        console.log('2:', app.globalData.openid);
        if (that.data.guanli_openId === app.globalData.openid) {
          that.setData({
            checked: res.data[0].duotou
          })
          console.log('3:', that.data.checked);
        }
        if (that.data.guanli_openId !== app.globalData.openid) {
          Dialog.confirm({
            title: '提示',
            message: '您没有设置本主题的权限！如需修改主题配置，请联系民调主题发起者！'
          }).then(() => {
             // on confirm

            wx.navigateTo({
              url: '../index/index',
            })
          }).catch(() => {
            // on cancel
          });
        }
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '更新失败'
        })
        console.error('更新失败：', err)
      }
    })
  },
  // 上传图片
  doUpload: function () {
    // 选择图片
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {

        wx.showLoading({
          title: '上传中',
        })

        const filePath = res.tempFilePaths[0]

        // 上传图片
        const cloudPath = 'my-image' + filePath.match(/\.[^.]+?$/)[0]
        wx.cloud.uploadFile({
          cloudPath,
          filePath,
          success: res => {
            console.log('[上传文件] 成功：', res)

            app.globalData.fileID = res.fileID
            app.globalData.cloudPath = cloudPath
            app.globalData.imagePath = filePath        
            wx.showToast({
              icon: 'none',
              title: '上传成功',
            })
          },
          fail: e => {
            console.error('[上传文件] 失败：', e)
            wx.showToast({
              icon: 'none',
              title: '上传失败',
            })
          },
          complete: () => {
            wx.hideLoading()
          }
        })

      },
      fail: e => {
        console.error(e)
      }
    })
  }
})