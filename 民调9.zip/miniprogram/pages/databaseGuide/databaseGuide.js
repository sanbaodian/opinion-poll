 // pages/databaseGuide/databaseGuide.js

const app = getApp()

Page({

  data: {
    step: 1,
    counterId: '',
    openid: '',
    count: 0,
    queryResult: '',
    zhuti: null,
    input2:false,
    input3: false,
    yiji:'',
    gangmu:[],
    gangmuId:'',
    gangmuNo:0
  },

  onLoad: function (options) {
    if (app.globalData.openid) {
      this.setData({
        openid: app.globalData.openid
      })
    };
    wx.showShareMenu({
      withShareTicket: true
    });
  },
  onShow(e) {
    wx.showShareMenu({
      withShareTicket: true
    })
  },
  onGetOpenid: function () {
    // 调用云函数
    wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        console.log('[云函数] [login] user openid: ', res.result.openid)
        app.globalData.openid = res.result.openid
        wx.navigateTo({
          url: '../databaseGuide/databaseGuide',
        })
      },
      fail: err => {
        console.error('调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },
  listenerInput: function (e) {
    console.log(e.detail.value);
    this.data.zhuti=e.detail.value;
    this.setData({
      zhuti:e.detail.value
    })
  },
  input2: function (e) {
    if (e.detail.value){
    this.setData({
      input2: true
    })
    }
  },

  yiji: function (e) {
    if (e.detail.value) {
      this.setData({
        yiji: e.detail.value
      })
      console.log(this.data.yiji)
    }
  },

  input3: function () {
      const db = wx.cloud.database()
      if (this.data.zhuti&&this.data.count==0) {
        db.collection('mindiao').add({
          data: {
            name: this.data.zhuti,
            gID: wx.getStorageSync('gID')
          },
          success: res => {
            //在返回结果中会包含新创建的主题的 _id
            this.setData({
              counterId: res._id,
              count: this.data.count + 1
            })
            console.log('主题创建成功，主题 _id: ', res._id);
            wx.setStorageSync('counterId', res._id);
          },
          fail: err => {
            wx.showToast({
              icon: 'none',
              title: '主题创建失败'
            })
            console.error('主题创建失败：', err)
          }
        })
      };
      this.setData({
        input3: true,
        gangmuNo: this.data.gangmuNo + 1
      });
      var jilu=this.data.gangmu;
      var obj={gangmu:this.data.yiji,up:0,down:0,del:false};
      jilu.push(obj);
    console.log(this.data.gangmu);

  },
  onAdd: function () {
     const db = wx.cloud.database()
    if (this.data.zhuti){
     db.collection('mindiao').add({
       data: {
         name: this.data.zhuti,
         gID: wx.getStorageSync('gID')
       },
       success: res => {
          //在返回结果中会包含新创建的记录的 _id
         this.setData({
           counterId: res._id,
           count: 1
         })
         wx.showToast({
           title: '新增记录成功',
         })
         console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)
       },
       fail: err => {
         wx.showToast({
           icon: 'none',
           title: '新增记录失败'
         })
         console.error('[数据库] [新增记录] 失败：', err)
       }
     })
    } 
  },
  wc_zhuti: function () {
    const db = wx.cloud.database()
    if (this.data.zhuti) {
      db.collection('mindiao').add({
        data: {
          name: this.data.zhuti,
          gID: wx.getStorageSync('gID'),
          input2:false
        },
        success: res => {
          //在返回结果中会包含新创建的记录的 _id
          this.setData({
            counterId: res._id,
            count: 1
          })
          wx.showToast({
            title: '发布主题成功',
          })
          console.log('成功，记录 _id: ', res._id);
          wx.setStorageSync('counterId', res._id);
          wx.navigateTo({
            url: '../deployFunctions/deployFunctions?counterId='+this.data.counterId,
          })
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '发布主题失败'
          })
          console.error('失败：', err)
        }
      })
    }
  },

  wc_gangmu: function () {
    const db = wx.cloud.database()
    for (var i = 0; i < this.data.gangmuNo; i++) {
      db.collection('yiji').add({
        data: {
          name: this.data.zhuti,
          gID: wx.getStorageSync('gID'),
          input3: false,
          gangmu: this.data.gangmu[i].gangmu,
          counterId: this.data.counterId,
          up:'0',
          down:'0',
          del:false
        },
        success: res => {
          //在返回结果中会包含新创建的记录的 _id
          wx.showToast({
            title: '发布主题民调成功',
          })
          console.log('成功，纲目 _id: ', res._id);
          wx.setStorageSync('gangmuId', res._id);
          this.setData({
            gangmuId: res._id
          })
          wx.navigateTo({
            url: '../deployFunctions/deployFunctions?counterId=' + this.data.counterId,
          })
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '发布纲目失败'
          })
          console.error('失败：', err)
        }
      })
    }
  },



  onQuery: function() {
     const db = wx.cloud.database()
     // 查询当前用户所有的 counters
     db.collection('counters').where({
       _openid: this.data.openid
     }).get({
       success: res => {
         this.setData({
           queryResult: JSON.stringify(res.data, null, 2)
         })
         console.log('[数据库] [查询记录] 成功: ', res)
       },
       fail: err => {
         wx.showToast({
           icon: 'none',
           title: '查询记录失败'
         })
         console.error('[数据库] [查询记录] 失败：', err)
       }
     })
  },

  onCounterInc: function() {
     const db = wx.cloud.database()
     const newCount = this.data.count + 1
     db.collection('counters').doc(this.data.counterId).update({
       data: {
         count: newCount
       },
       success: res => {
         this.setData({
           count: newCount
         })
       },
       fail: err => {
         icon: 'none',
         console.error('[数据库] [更新记录] 失败：', err)
       }
     })
  },

  onCounterDec: function() {
     const db = wx.cloud.database()
     const newCount = this.data.count - 1
     db.collection('counters').doc(this.data.counterId).update({
       data: {
         count: newCount
       },
       success: res => {
         this.setData({
           count: newCount
         })
       },
       fail: err => {
         icon: 'none',
         console.error('[数据库] [更新记录] 失败：', err)
       }
     })
  },

  onRemove: function() {
     if (this.data.counterId) {
       const db = wx.cloud.database()
       db.collection('counters').doc(this.data.counterId).remove({
         success: res => {
           wx.showToast({
             title: '删除成功',
           })
           this.setData({
             counterId: '',
             count: null,
           })
         },
         fail: err => {
           wx.showToast({
             icon: 'none',
             title: '删除失败',
           })
           console.error('[数据库] [删除记录] 失败：', err)
         }
       })
     } else {
       wx.showToast({
         title: '无记录可删，请见创建一个记录',
       })
     }
  },

  nextStep: function () {
     //在第一步，需检查是否有 openid，如无需获取
    if (this.data.step === 1 && !this.data.openid) {
      wx.cloud.callFunction({
        name: 'login',
        data: {},
        success: res => {
          app.globalData.openid = res.result.openid
          this.setData({
            step: 2,
            openid: res.result.openid
          })
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '获取 openid 失败，请检查是否有部署 login 云函数',
          })
          console.log('[云函数] [login] 获取 openid 失败，请检查是否有部署云函数，错误信息：', err)
        }
      })
    } else {
      this.setData({
        step: this.data.step + 1
      })
    }
  },

  prevStep: function () {
    this.setData({
      step: this.data.step - 1
    })
  },

  goHome: function() {
    const pages = getCurrentPages()
    if (pages.length === 2) {
      wx.navigateBack()
    } else if (pages.length === 1) {
      wx.redirectTo({
        url: '../index/index',
      })
    } else {
      wx.reLaunch({
        url: '../index/index',
      })
    }
  }

})