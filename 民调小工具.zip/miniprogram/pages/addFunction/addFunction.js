// pages/addFunction/addFunction.js
const app = getApp()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`

Page({

  data: {
    openid: '',
    avatarUrl: '../index/user-unlogin.png',
    counterId: '',
    zhuti: [],
    timu: '',
    gangmu: [],
    temp_gangmu: [],
    tmp_openId: '',
    tmp_openGId: '',
    tmp_up: '',
    tmp_down: '',
    index: '',
    iconType: [
      'info', 'clear'
    ],
    result: '',
    count:0,
    canIUseClipboard: wx.canIUse('setClipboardData'),
  },

  onLoad: function (options) {

  },

  copyCode: function() {
    wx.setClipboardData({
      data: code,
      success: function () {
        wx.showToast({
          title: '复制成功',
        })
      }
    })
  },

  testFunction() {
    wx.cloud.callFunction({
      name: 'sum',
      data: {
        a: 1,
        b: 2
      },
      success: res => {
        wx.showToast({
          title: '调用成功',
        })
        this.setData({
          result: JSON.stringify(res.result)
        })
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '调用失败',
        })
        console.error('[云函数] [sum] 调用失败：', err)
      }
    })
  },




 

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.onGetOpenid();
    this.onQuery();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {


  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  onGetOpenid: function () {
    // 调用云函数
    wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        console.log('主题内容页面 openid: ', res.result.openid)
        app.globalData.openid = res.result.openid;
        this.setData({
          openid: res.result.openid
        })
        fail: err => {
          console.error('[云函数] [login] 调用失败', err)
          wx.navigateTo({
            url: '../deployFunctions/deployFunctions',
          })
        }
      }
    })
  },

  onQuery: function () {
    console.log("START");
    const db = wx.cloud.database()
    db.collection('mindiao').where({
      _openid: app.globalData.openid
    }).get({
      success: res =>  {
        this.setData({
          zhuti: res.data
        })
        console.log(res.data);
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('数据查询 失败：', err)
      }
    })
  },

  gm_onQuery: function () {
    const db = wx.cloud.database()
    db.collection('yiji').where({
      counterId: this.data.counterId
    }).get({
      success: res => {
        this.setData({
          gangmu: res.data
        })
        console.log('纲目数据获取成功: ', res.data);

      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('纲目数据获取失败：', err)
      }
    })
  },
  onCounterInc: function () {
    const db = wx.cloud.database()
    const newCount = this.data.count + 1
    db.collection('counters').doc(this.data.counterId).update({
      data: {
        count: newCount
      },
      success: res => {
        this.setData({
          count: newCount
        })
      },
      fail: err => {
        icon: 'none',
          console.error('[数据库] [更新记录] 失败：', err)
      }
    })
  },

  onCounterDec: function () {
    const db = wx.cloud.database()
    const newCount = this.data.count - 1
    db.collection('counters').doc(this.data.counterId).update({
      data: {
        count: newCount
      },
      success: res => {
        this.setData({
          count: newCount
        })
      },
      fail: err => {
        icon: 'none',
          console.error('[数据库] [更新记录] 失败：', err)
      }
    })
  },

  onRemove: function () {
    if (this.data.counterId) {
      const db = wx.cloud.database()
      db.collection('counters').doc(this.data.counterId).remove({
        success: res => {
          wx.showToast({
            title: '删除成功',
          })
          this.setData({
            counterId: '',
            count: null,
          })
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '删除失败',
          })
          console.error('[数据库] [删除记录] 失败：', err)
        }
      })
    } else {
      wx.showToast({
        title: '无记录可删，请见创建一个记录',
      })
    }
  },
  goHome: function () {
    const pages = getCurrentPages()
    if (pages.length === 2) {
      wx.navigateBack()
    } else if (pages.length === 1) {
      wx.redirectTo({
        url: '../index/index',
      })
    } else {
      wx.reLaunch({
        url: '../index/index',
      })
    }
  },

  readDetail: function (e) {
    //点击列表项函数
    var index = e.currentTarget.dataset.id; //打印可以看到，此处已获取到了对应的id
    console.log(index);
    wx.navigateTo({
      url: '../deployFunctions/deployFunctions?counterId=' + index,
    })
   
  },
  /**
   * 用户点击右上角分享
   */
  //分享
  onShareAppMessage: function (res) {
    let that = this
    return {
      title: "主题民调：" + this.data.timu,
      path: '../deployFunctions/deployFunctions?counterId=' + this.data.counterId,
      success: function (res) {
        //getSystemInfo是为了获取当前设备信息，判断是android还是ios，如果是android
        //还需要调用wx.getShareInfo()，只有当成功回调才是转发群，ios就只需判断shareTickets
        //获取用户设备信息
        wx.getSystemInfo({
          success: function (d) {
            console.log(d);
            //判断用户手机是IOS还是Android
            if (d.platform == 'android') {
              wx.getShareInfo({ //获取群详细信息
                shareTicket: res.shareTickets,
                success: function (res) {
                  //这里写你分享到群之后要做的事情，比如增加次数什么的
                },
                fail: function (res) { //这个方法就是分享到的是好友，给一个提示
                  wx.showModal({
                    title: '提示',
                    content: '分享好友无效，请分享群',
                    success: function (res) {
                      if (res.confirm) {
                        console.log('用户点击确定')
                      } else if (res.cancel) {
                        console.log('用户点击取消')
                      }
                    }
                  })
                }
              })
            }
            if (d.platform == 'ios') { //如果用户的设备是IOS
              if (res.shareTickets != undefined) {
                console.log("分享的是群");
                wx.getShareInfo({
                  shareTicket: res.shareTickets,
                  success: function (res) {
                    //分享到群之后你要做的事情
                  }
                })

              } else { //分享到个人要做的事情，我给的是一个提示
                console.log("分享的是个人");
                wx.showModal({
                  title: '提示',
                  content: '分享好友无效，请分享群',
                  success: function (res) {
                    if (res.confirm) {
                      console.log('用户点击确定')
                    } else if (res.cancel) {
                      console.log('用户点击取消')
                    }
                  }
                })
              }
            }

          },
          fail: function (res) {

          }
        })
      }

    }
  }

})

