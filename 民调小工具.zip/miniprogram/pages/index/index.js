//index.js
const app = getApp()
const db = wx.cloud.database()
const _ = db.command
import Dialog from '../../vant/dialog/dialog';
Page({
  data: {
    avatarUrl: './user-unlogin.png',
    currentTab: 0,
    userInfo: {},
    logged: false,
    takeSession: false,
    requestResult: '',
    openGId: '',
    loginid: '',
    counterId: '',
    show: false,
    username: '',
    password: '',
    zhuti: [],
    zhuti1: [],
    hasMore: true,
    lastId: '0',
    selectedtype: 'mindiao',
    selectedTagId: '',
    pageNum: 1,
    s1: 0,
    hasMore1: true,
    lastId1: 0,
    selectedtype1: 'mindiao',
    selectedTagId1: '',
    pageNum1: 1,
    s2: 0,
    newzhuti: '',
    imgUrl: 'gh_a3d38ed3a806_258.jpg'
  },

  onLoad: function(options) {
      wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        console.log('[2]openid: ', res.result.openid);
        app.globalData.openid = res.result.openid;
        console.log("[3]全局openid:" + res.result.openid);
        wx.setStorageSync('login', res.result.openid)

        this.setData({
          loginid: res.result.openid
        });
        console.log("[4]获取loginid:" + this.data.loginid);
        this.huoquTuijianListData('mindiao');
        this.huoquWodeListData('mindiao');
      },
      fail: err => {
        console.error('调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
    console.log("[5]获取gID:" + wx.getStorageSync('gID'));
    console.log("[6]获取counterId:" + wx.getStorageSync('counterId'));
    this.setData({
      openGId: wx.getStorageSync('gID')
    })
    wx.showShareMenu({
      withShareTicket: true
    });
    if (!wx.cloud) {
      wx.redirectTo({
        url: '../chooseLib/chooseLib',
      })
      return
    }

    
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
   
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {


  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  onShow(e) {
    wx.showShareMenu({
      withShareTicket: true
    })
  },

  onGetUserInfo: function(e) {
    if (!this.logged && e.detail.userInfo) {
      this.setData({
        logged: true,
        avatarUrl: e.detail.userInfo.avatarUrl,
        userInfo: e.detail.userInfo
      })
    }
  },

  onGetOpenid: function() {
    // 调用云函数
    var that = this;
    wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        console.log('[7]openid: ', res.result.openid);
        app.globalData.openid = res.result.openid;
        console.log("[8]全局openid:" + res.result.openid);
        wx.setStorage({
          key: 'loginid', data: res.result.openid
        })
        that.setData({
          loginid: res.result.openid
        });
        console.log("[9]获取loginid:" + that.data.loginid);        
      },
      fail: err => {
        console.error('调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })

  },


  

  //分享


  // 上传图片
  doUpload: function() {
    // 选择图片
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function(res) {

        wx.showLoading({
          title: '上传中',
        })

        const filePath = res.tempFilePaths[0]

        // 上传图片
        const cloudPath = 'my-image' + filePath.match(/\.[^.]+?$/)[0]
        wx.cloud.uploadFile({
          cloudPath,
          filePath,
          success: res => {
            console.log('[上传文件] 成功：', res)

            app.globalData.fileID = res.fileID
            app.globalData.cloudPath = cloudPath
            app.globalData.imagePath = filePath

            wx.navigateTo({
              url: '../storageConsole/storageConsole'
            })
          },
          fail: e => {
            console.error('[上传文件] 失败：', e)
            wx.showToast({
              icon: 'none',
              title: '上传失败',
            })
          },
          complete: () => {
            wx.hideLoading()
          }
        })

      },
      fail: e => {
        console.error(e)
      }
    })
  },
  huoquTuijianListData: function() {
    var that = this;
    //获取相应类型的列表
    console.log("推荐主题页码：" + this.data.pageNum + "最后一个ID:" + this.data.lastId + "跳过：" + this.data.s1) 
    var loginid = this.data.loginid;
    console.log("[10]--------openid:" + loginid);

if(this.data.pageNum === 1){

  var db = wx.cloud.database()
  db.collection('mindiao')
    .where({
      gID: '',
      _id: _.gt(this.data.lastId)
    })
    .limit(8)
    .get({
      success: function (res) {
        wx.showLoading({
          title: '加载中',
        })
        console.log("推荐主题第" + that.data.pageNum + "次获取")
        wx.hideLoading()
        console.log(res)
        if (res.data.length < 8) {
          that.data.hasMore = false;
          for (var i = 0; i < res.data.length; i++) {
            var data = res.data[i]
            that.data.zhuti.push(data)
            if (i + 1 == res.data.length) {
              that.data.lastId = data._id
            }
          }
        } else {
          that.data.hasMore = true
          for (var i = 0; i < res.data.length; i++) {
            var data = res.data[i]
            that.data.zhuti.push(data)
            if (i + 1 == res.data.length) {
              that.data.lastId = data._id
            }
          }
        }
        that.setData({
          zhuti: that.data.zhuti,
          selectedtype: "tuijian",
          pageNum: that.data.pageNum * 1 + 1,
          lastId: that.data.lastId * 1,
          hasMore: that.data.hasMore
        })
      },
      fail: function (res) {
        //找不到该数据库
        console.log("===fail===" + res)
        wx.hideLoading()
      },
    })
}
else{
    
      var db = wx.cloud.database()
      db.collection('mindiao')
        .where({
          gID: '',
        
        })
        .skip(that.data.s1 * 1)
        .limit(8)
        .get({
          success: function (res) {
            wx.showLoading({
              title: '加载中',
            })
            console.log(res)
            wx.hideLoading()
            if (res.data.length < 8) {
              that.data.hasMore = false
            } else {
              that.data.hasMore = true
              for (var i = 0; i < res.data.length; i++) {
                var data = res.data[i]
                that.data.zhuti.push(data);
                console.log(that.data.zhuti)
                if (i + 1 == res.data.length) {
                  that.data.lastId = data._id
                }
              }
            }
            that.setData({
              zhuti: that.data.zhuti,
              selectedtype: "tuijian",
              pageNum: that.data.pageNum * 1 + 1,
              lastId: that.data.lastId * 1,
              hasMore: that.data.hasMore
            })
          },
          fail: function (res) {
            //找不到该数据库
            console.log("===fail===" + res)
            wx.hideLoading()
          },
        })
    }
  },
    huoquWodeListData: function() {
      var that = this;
      //获取相应类型的列表
      console.log("我的主题页码：" + this.data.pageNum + "最后一个ID:" + this.data.lastId + "跳过：" + this.data.s1)
      var loginid = this.data.loginid;
      console.log("[11]--------openid:" + loginid);

      if (this.data.pageNum1 === 1) {
        var db = wx.cloud.database();
        db.collection('mindiao')
          .where({
            _openid: loginid,
          })
          .limit(8)
          .get({
            success: function (res) {
              wx.showLoading({
                title: '加载中',
              })
              console.log("我的主题第"+ that.data.pageNum1 +"次获取")
              wx.hideLoading()
              console.log(res)
              if (res.data.length < 8) {
                that.data.hasMore1 = false;
                for (var i = 0; i < res.data.length; i++) {
                  var data1 = res.data[i]
                  that.data.zhuti1.push(data1);
    
                  if (i + 1 == res.data.length) {
                    that.data.lastId1 = data1._id
                  }
                }
              } else {
                that.data.hasMore1 = true
                for (var i = 0; i < res.data.length; i++) {
                  var data1 = res.data[i]
                  that.data.zhuti1.push(data1);
                  
                  if (i + 1 == res.data.length) {
                    that.data.lastId1 = data1._id
                  }
                }
              }
              that.setData({
                zhuti1: that.data.zhuti1,
                selectedtype1: "wode",
                pageNum1: that.data.pageNum1 * 1 + 1,
                lastId1: that.data.lastId1 * 1,
                hasMore1: that.data.hasMore1
              })
            },
            fail: function (res) {
              //找不到该数据库
              console.log("===fail===" + res)
              wx.hideLoading()
            },
          })


      

      }
      else{
    
        var db = wx.cloud.database();
        db.collection('mindiao')
          .where({
            _openid: loginid,
          
          })
          .skip(that.data.s2 * 1)
          .limit(8)
          .get({
            success: function (res) {
              wx.showLoading({
                title: '加载中',
              })
              console.log(res)
              wx.hideLoading()
              if (res.data.length < 8) {
                if (that.data.pageNum1 == 1) {
                  that.data.zhuti1 = []
                }
                that.data.hasMore1 = false
              } else {
                that.data.hasMore1 = true
                for (var i = 0; i < res.data.length; i++) {
                  var data1 = res.data[i]
                  that.data.zhuti1.push(data1);
                  console.log(that.data.zhuti1)
                  if (i + 1 == res.data.length) {
                    that.data.lastId1 = data1._id
                  }
                }
              }
              that.setData({
                zhuti1: that.data.zhuti1,
                selectedtype1: "wode",
                pageNum1: that.data.pageNum1 * 1 + 1,
                lastId1: that.data.lastId1 * 1,
                hasMore1: that.data.hasMore1
              })
            },
            fail: function (res) {
              //找不到该数据库
              console.log("===fail===" + res)
              wx.hideLoading()
            },
          })


      }

 
    
  },
  
  gm_onQuery: function() {
    const db = wx.cloud.database()
    db.collection('yiji').where({
      counterId: this.data.counterId
    }).get({
      success: res => {
        this.setData({
          gangmu: res.data
        })
        console.log('纲目数据获取成功: ', res.data);

      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('纲目数据获取失败：', err)
      }
    })
  },

  goHome: function() {
    const pages = getCurrentPages()
    if (pages.length === 2) {
      wx.navigateBack()
    } else if (pages.length === 1) {
      wx.redirectTo({
        url: '../index/index',
      })
    } else {
      wx.reLaunch({
        url: '../index/index',
      })
    }
  },

  readDetail: function(e) {
    //点击列表项函数
    var index = e.currentTarget.dataset.id; //打印可以看到，此处已获取到了对应的id
    console.log(index);
    wx.navigateTo({
      url: '../deployFunctions/deployFunctions?counterId=' + index,
    })

  },
  new: function() {
    // wx.navigateTo({
    //  url: '../databaseGuide/databaseGuide',
    // })
    this.setData({
      show: true
    })
  },

  help: function() {
    //wx.navigateTo({
    // url: '../help/help',
    // })
    Dialog.alert({
      title: '帮助',
      message: '民调，民意调查也。三个动作玩转民调小程序：　★☆☆　抛出一个民调主题（新建）　★★☆　扔出一个选项（增项）　★★★　投上一票（点击选项即支持此选项一票）　☺　备注：只有自己增加的选项，才能被自己点击选择后删除。'
    }).then(() => {
      // on close
    });
  },
  onChange(event) {
    // event.detail 为当前输入的值
    console.log(event.detail);
    this.setData({
      newzhuti: event.detail
    })
  },
  onClose(event) {
    if (event.detail === 'confirm') {
      // 异步关闭弹窗
      setTimeout(() => {

        const db = wx.cloud.database()
        if (this.data.newzhuti) {
          db.collection('mindiao').add({
            data: {
              name: this.data.newzhuti,
              gID: wx.getStorageSync('gID')
            },
            success: res => {
              //在返回结果中会包含新创建的主题的 _id
              this.setData({
                counterId: res._id
              })
              console.log('创建成功，主题 _id: ', res._id);
              wx.setStorageSync('counterId', res._id);
              wx.navigateTo({
                url: '../deployFunctions/deployFunctions?counterId=' + res._id,
              })
            },
            fail: err => {
              wx.showToast({
                icon: 'none',
                title: '主题创建失败'
              })
              console.error('主题创建失败：', err)
            }
          })
        };

        this.setData({
          show: false
        });
      }, 1000);
    } else {
      this.setData({
        show: false
      });
    }
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    if (!this.data.hasMore) {
      return;
    } else {
      console.log("推荐主题页码：" + this.data.pageNum)

      var s1 = this.data.s1 + 8;
      this.setData({
        s1: s1
      })
      console.log("推荐主题跳过：" + this.data.s1);
      this.huoquTuijianListData();
    }

    if (!this.data.hasMore1) {
      return;
    } else {
      console.log("我的主题页码：" + this.data.pageNum1)

      var s2 = this.data.s2 + 8;
      this.setData({
        s2: s2
      })
      console.log("我的主题跳过：" + this.data.s2);
      this.huoquWodeListData();

    }
  }





})