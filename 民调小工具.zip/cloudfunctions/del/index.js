const cloud = require('wx-server-sdk')
cloud.init({
  env: 'mindiao-6311b9'
})
const db = cloud.database()
const _ = db.command
exports.main = async (event, context) => {
  try {
    return await db.collection('yiji').doc(event.id).remove()
  } catch (e) {
    console.error(e)
  }
}